/*
 *  Copyright (C) 2005-2019 Team Kodi
 *  This file is part of Kodi - https://kodi.tv
 *
 *  SPDX-License-Identifier: GPL-2.0-or-later
 *  See LICENSES/README.md for more information.
 */

#pragma once

#ifdef WIN32

#undef GL_GLES_PROTOTYPES
#include <angle_gl.h>
#include <EGL/egl.h>
#include <EGL/eglext.h>

#include <d3d11.h>
#include <DirectXMath.h>
#include <DirectXPackedVector.h>
#include <kodi/General.h>

#include "../dx/DefaultPixelShader.inc"
#include "../dx/DefaultVertexShader.inc"

namespace kodi
{
namespace gui
{
namespace gl
{

template <typename outType>
outType *DynamicCastComObject(IUnknown *object)
{
  outType *outObject = nullptr;
  HRESULT result =
    object->QueryInterface(__uuidof(outType), reinterpret_cast<void **>(&outObject));
  if (SUCCEEDED(result))
  {
    return outObject;
  }
  else
  {
    SafeRelease(outObject);
    return nullptr;
  }
}

template <typename T, unsigned int N>
void SafeRelease(T(&resourceBlock)[N])
{
  for (unsigned int i = 0; i < N; i++)
  {
    SafeRelease(resourceBlock[i]);
  }
}

template <typename T>
void SafeRelease(T &resource)
{
  if (resource)
  {
    resource->Release();
    resource = nullptr;
  }
}

class ATTRIBUTE_HIDDEN CGLtoDX
{
public:
  CGLtoDX(int x, int y, int width, int height, void* device)
    : m_x(x), m_y(y), m_width(width), m_height(height), m_context(reinterpret_cast<ID3D11DeviceContext*>(device))
  {
  }

  virtual ~CGLtoDX() = default;

  bool GLtoDXCreate()
  {
    //m_context = reinterpret_cast<ID3D11DeviceContext*>(Device());
    m_context->GetDevice(&m_device);

    // compile the two shaders
    // encapsulate both shaders into shader objects
    m_device->CreateVertexShader(DefaultVertexShaderCode, sizeof(DefaultVertexShaderCode), NULL, &m_vertexShader);
    m_device->CreatePixelShader(DefaultPixelShaderCode, sizeof(DefaultPixelShaderCode), NULL, &m_pixelShader);

    // set the shader objects
    m_context->VSSetShader(m_vertexShader, 0, 0);
    m_context->PSSetShader(m_pixelShader, 0, 0);

    // create the input layout object
    D3D11_INPUT_ELEMENT_DESC layout[] =
    {
      {"POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0},
      {"TEXCOORD0", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 12, D3D11_INPUT_PER_VERTEX_DATA, 0},
    };

    m_device->CreateInputLayout(layout, ARRAYSIZE(layout), DefaultVertexShaderCode, sizeof(DefaultVertexShaderCode), &m_inputLayout);
    m_context->IASetInputLayout(m_inputLayout);

    // create a triangle using the VERTEX struct
    VERTEX OurVertices[] =
    {
      { -1.0f, -1.0f, 0.0f, 0.0f, 0.0f },
      { -1.0f,  1.0f, 0.0f, 0.0f, 1.0f },
      {  1.0f, -1.0f, 0.0f, 1.0f, 0.0f },
      {  1.0f,  1.0f, 0.0f, 1.0f, 1.0f }
    };

    // create the vertex buffer
    D3D11_BUFFER_DESC bd;
    ZeroMemory(&bd, sizeof(bd));

    bd.Usage = D3D11_USAGE_DYNAMIC;                // write access access by CPU and GPU
    bd.ByteWidth = sizeof(VERTEX) * 4;             // size is the VERTEX struct * 3
    bd.BindFlags = D3D11_BIND_VERTEX_BUFFER;       // use as a vertex buffer
    bd.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;    // allow CPU to write in buffer

    m_device->CreateBuffer(&bd, NULL, &m_buffer);       // create the buffer

    // copy the vertices into the buffer
    D3D11_MAPPED_SUBRESOURCE ms;
    m_context->Map(m_buffer, NULL, D3D11_MAP_WRITE_DISCARD, NULL, &ms);    // map the buffer
    memcpy(ms.pData, OurVertices, sizeof(OurVertices));                 // copy the data
    m_context->Unmap(m_buffer, NULL);

    //--------------------------------------------------------------------------------------

    int clientVersion = 3;
    bool usePresentPathFast = false;
    // Set up EGL Display
    EGLint displayAttribs[] =
    {
      EGL_PLATFORM_ANGLE_TYPE_ANGLE,                EGL_PLATFORM_ANGLE_TYPE_D3D11_ANGLE,
      EGL_PLATFORM_ANGLE_MAX_VERSION_MAJOR_ANGLE,   EGL_DONT_CARE,
      EGL_PLATFORM_ANGLE_MAX_VERSION_MAJOR_ANGLE,   EGL_DONT_CARE,
      EGL_EXPERIMENTAL_PRESENT_PATH_ANGLE,          usePresentPathFast ? EGL_EXPERIMENTAL_PRESENT_PATH_FAST_ANGLE
                                                                       : EGL_EXPERIMENTAL_PRESENT_PATH_COPY_ANGLE,
      EGL_NONE
    };

    EGLNativeDisplayType mNativeDisplay = GetDC(GetActiveWindow());
    m_eglDisplay = eglGetPlatformDisplayEXT(EGL_PLATFORM_ANGLE_ANGLE, EGL_DEFAULT_DISPLAY, displayAttribs);
    if (m_eglDisplay == EGL_NO_DISPLAY)
    {
      kodi::Log(ADDON_LOG_ERROR, "Failed to get EGL platform display '%s'", eglGetErrorString(eglGetError()));
      return false;
    }

    if (eglInitialize(m_eglDisplay, &m_eglMajorVersion, &m_eglMinorVersion) == EGL_FALSE)
    {
      kodi::Log(ADDON_LOG_ERROR, "Failed to initialize EGL '%s'", eglGetErrorString(eglGetError()));
      return false;
    }

    EGLint numConfigs = 0;
    // Choose the EGL config
    EGLint configAttribs[] =
    {
      EGL_RED_SIZE,             8,
      EGL_GREEN_SIZE,           8,
      EGL_BLUE_SIZE,            8,
      EGL_ALPHA_SIZE,           8,
      EGL_BIND_TO_TEXTURE_RGBA, EGL_TRUE,
      EGL_RENDERABLE_TYPE,      clientVersion == 3 ? EGL_OPENGL_ES3_BIT : EGL_OPENGL_ES2_BIT,
      EGL_SURFACE_TYPE,         EGL_PBUFFER_BIT,
      EGL_NONE
    };
    if (!eglChooseConfig(m_eglDisplay, configAttribs, &m_eglConfig, 1, &numConfigs))
    {
      kodi::Log(ADDON_LOG_ERROR, "Failed to choose EGL config '%s'", eglGetErrorString(eglGetError()));
      return false;
    }

    // Set up the EGL context
    EGLint contextAttribs[] =
    {
      EGL_CONTEXT_CLIENT_VERSION, clientVersion,
      EGL_NONE
    };
    m_eglContext = eglCreateContext(m_eglDisplay, m_eglConfig, nullptr, contextAttribs);
    if (m_eglContext == EGL_NO_CONTEXT)
    {
      kodi::Log(ADDON_LOG_ERROR, "Failed to create EGL context '%s'", eglGetErrorString(eglGetError()));
      return false;
    }

    D3D11_TEXTURE2D_DESC textureDesc = { 0 };
    textureDesc.Width = m_width;
    textureDesc.Height = m_height;
    textureDesc.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
    textureDesc.MipLevels = 1;
    textureDesc.ArraySize = 1;
    textureDesc.SampleDesc.Count = 1;
    textureDesc.SampleDesc.Quality = 0;
    textureDesc.Usage = D3D11_USAGE_DEFAULT;
    textureDesc.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
    textureDesc.CPUAccessFlags = 0;
    textureDesc.MiscFlags = D3D11_RESOURCE_MISC_SHARED;

    if (!SUCCEEDED(m_device->CreateTexture2D(&textureDesc, nullptr, &m_offscreenD3D11Tex)))
    {
      kodi::Log(ADDON_LOG_ERROR, "Failed to create DirectX 2D texture");
      return false;
    }

    IDXGIResource *dxgiResource = DynamicCastComObject<IDXGIResource>(m_offscreenD3D11Tex);
    if (dxgiResource == nullptr)
    {
      kodi::Log(ADDON_LOG_ERROR, "Failed to get DirectX 2D texture");
      return false;
    }

    HANDLE sharedHandle = 0;
    if (!SUCCEEDED(dxgiResource->GetSharedHandle(&sharedHandle)))
    {
      kodi::Log(ADDON_LOG_ERROR, "Failed to get shared handle");
      return false;
    }
    SafeRelease(dxgiResource);

    EGLint pBufferAttributes[] =
    {
      EGL_WIDTH,          m_width,
      EGL_HEIGHT,         m_height,
      EGL_TEXTURE_TARGET, EGL_TEXTURE_2D,
      EGL_TEXTURE_FORMAT, EGL_TEXTURE_RGBA,
      EGL_NONE
    };

    m_eglSurface = eglCreatePbufferFromClientBuffer(m_eglDisplay, EGL_D3D_TEXTURE_2D_SHARE_HANDLE_ANGLE,
      sharedHandle, m_eglConfig, pBufferAttributes);
    if (m_eglSurface == EGL_NO_SURFACE)
    {
      kodi::Log(ADDON_LOG_ERROR, "Failed to create pbuffer from client buffer %s", eglGetErrorString(eglGetError()));
      return false;
    }

    eglMakeCurrent(m_eglDisplay, m_eglSurface, m_eglSurface, m_eglContext);

    CD3D11_SHADER_RESOURCE_VIEW_DESC srvDesc(m_offscreenD3D11Tex, D3D11_SRV_DIMENSION_TEXTURE2D);
    m_device->CreateShaderResourceView(m_offscreenD3D11Tex, &srvDesc, m_views);
    return true;
  }

  void GLtoDXDestroy()
  {
    if (m_eglDisplay != EGL_NO_DISPLAY)
    {
      eglMakeCurrent(m_eglDisplay, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);

      if (m_eglSurface != EGL_NO_SURFACE)
      {
        eglDestroySurface(m_eglDisplay, m_eglSurface);
        m_eglSurface = EGL_NO_SURFACE;
      }

      if (m_eglContext != EGL_NO_CONTEXT)
      {
        eglDestroyContext(m_eglDisplay, m_eglContext);
        m_eglContext = EGL_NO_CONTEXT;
      }

      eglTerminate(m_eglDisplay);
      m_eglDisplay = EGL_NO_DISPLAY;
    }

    if (m_views[0])
    {
      m_views[0]->Release();
      m_views[0] = nullptr;
    }

    if (m_inputLayout)
    {
      m_inputLayout->Release();
      m_inputLayout = nullptr;
    }

    if (m_vertexShader)
    {
      m_vertexShader->Release();
      m_vertexShader = nullptr;
    }

    if (m_pixelShader)
    {
      m_pixelShader->Release();
      m_pixelShader = nullptr;
    }

    if (m_buffer)
    {
      m_buffer->Release();
      m_buffer = nullptr;
    }

    if (m_offscreenD3D11Tex)
    {
      m_offscreenD3D11Tex->Release();
      m_offscreenD3D11Tex = nullptr;
    }
  }

  void GLtoDXRenderBegin()
  {
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
  }

  void GLtoDXRenderEnd()
  {
    glFlush();

    // select which vertex buffer to display
    UINT stride = sizeof(VERTEX), offset = 0;
    m_context->IASetVertexBuffers(0, 1, &m_buffer, &stride, &offset);

    m_context->VSSetShader(m_vertexShader, nullptr, 0);
    m_context->PSSetShader(m_pixelShader, nullptr, 0);
    m_context->PSSetShaderResources(0, 1, m_views);

    m_context->IASetInputLayout(m_inputLayout);

    // select which primtive type we are using
    m_context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);

    // draw the vertex buffer to the back buffer
    m_context->Draw(4, 0);

    m_context->PSSetShader(nullptr, nullptr, 0);
    m_context->VSSetShader(nullptr, nullptr, 0);
  }

private:
#define CASE_STR( value ) case value: return #value; 
  const char* eglGetErrorString(EGLint error)
  {
    switch (error)
    {
      CASE_STR(EGL_SUCCESS)
        CASE_STR(EGL_NOT_INITIALIZED)
        CASE_STR(EGL_BAD_ACCESS)
        CASE_STR(EGL_BAD_ALLOC)
        CASE_STR(EGL_BAD_ATTRIBUTE)
        CASE_STR(EGL_BAD_CONTEXT)
        CASE_STR(EGL_BAD_CONFIG)
        CASE_STR(EGL_BAD_CURRENT_SURFACE)
        CASE_STR(EGL_BAD_DISPLAY)
        CASE_STR(EGL_BAD_SURFACE)
        CASE_STR(EGL_BAD_MATCH)
        CASE_STR(EGL_BAD_PARAMETER)
        CASE_STR(EGL_BAD_NATIVE_PIXMAP)
        CASE_STR(EGL_BAD_NATIVE_WINDOW)
        CASE_STR(EGL_CONTEXT_LOST)
    default: return "Unknown";
    }
  }
#undef CASE_STR

  // a struct to define a single vertex
  struct VERTEX
  {
    FLOAT X, Y, Z;
    float Color[4];
    float u, v;
  };

  int m_x;
  int m_y;
  int m_width;
  int m_height;

  EGLint m_eglMajorVersion;
  EGLint m_eglMinorVersion;
  EGLConfig m_eglConfig;
  EGLDisplay m_eglDisplay;
  EGLSurface m_eglSurface;
  EGLContext m_eglContext;

  ID3D11Texture2D* m_offscreenD3D11Tex = nullptr;
  ID3D11Device* m_device = nullptr;
  ID3D11DeviceContext* m_context = nullptr;
  ID3D11VertexShader* m_vertexShader = nullptr;
  ID3D11PixelShader* m_pixelShader = nullptr;
  ID3D11InputLayout* m_inputLayout = nullptr;
  ID3D11ShaderResourceView* m_views[1] = { nullptr };
  ID3D11Buffer* m_buffer = nullptr;
};

} /* namespace gl */
} /* namespace gui */
} /* namespace kodi */

#else
#error Use of GLonDX.h only be available under Windows and this header should never included direct, use always GL.h!
#endif
