/*
 *  Copyright (C) 2005-2019 Team Kodi
 *  This file is part of Kodi - https://kodi.tv
 *
 *  SPDX-License-Identifier: GPL-2.0-or-later
 *  See LICENSES/README.md for more information.
 */

#pragma once

//============================================================================
///
/// \defgroup cpp_kodi_gui_gl Kodi OpenGL helpers
/// \ingroup cpp_kodi_gui
/// \brief Auxiliary functions for Open GL
///
/// This group includes help for definitions, functions, and classes for
/// OpenGL.
///
/// To use OpenGL for your system, add the \ref GL.h "#include <kodi/gui/gl/GL.h>".
///

#ifdef WIN32
  #define HAS_GLES 2
  #include "GLonDX.h"
#elif HAS_GL
  // always define GL_GLEXT_PROTOTYPES before include gl headers
  #if !defined(GL_GLEXT_PROTOTYPES)
    #define GL_GLEXT_PROTOTYPES
  #endif
  #if defined(TARGET_LINUX)
    #include <GL/gl.h>
    #include <GL/glext.h>
  #elif defined(TARGET_FREEBSD)
    #include <GL/gl.h>
  #elif defined(TARGET_DARWIN)
    #include <OpenGL/gl3.h>
    #include <OpenGL/gl3ext.h>
  #endif
#elif HAS_GLES >= 2
  #if defined(TARGET_DARWIN)
    #if HAS_GLES == 3
      #include <OpenGLES/ES3/gl.h>
      #include <OpenGLES/ES3/glext.h>
    #else
      #include <OpenGLES/ES2/gl.h>
      #include <OpenGLES/ES2/glext.h>
    #endif
  #else
    #if HAS_GLES == 3
      #include <GLES3/gl3.h>
      #include <GLES3/gl3ext.h>
    #else
      #include <GLES2/gl2.h>
      #include <GLES2/gl2ext.h>
    #endif
  #endif
#endif

#ifndef BUFFER_OFFSET
#define BUFFER_OFFSET(i) ((char *)nullptr + (i))
#endif
